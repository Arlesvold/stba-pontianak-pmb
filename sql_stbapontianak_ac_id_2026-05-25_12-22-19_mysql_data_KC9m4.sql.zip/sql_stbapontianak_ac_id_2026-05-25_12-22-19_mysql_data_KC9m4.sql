/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: sql_stbapontianak_ac_id
-- ------------------------------------------------------
-- Server version	10.11.10-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agendas`
--

DROP TABLE IF EXISTS `agendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agendas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agendas`
--

LOCK TABLES `agendas` WRITE;
/*!40000 ALTER TABLE `agendas` DISABLE KEYS */;
/*!40000 ALTER TABLE `agendas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `beritas`
--

DROP TABLE IF EXISTS `beritas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beritas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `ringkasan` text DEFAULT NULL,
  `isi` longtext NOT NULL,
  `tanggal` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `beritas_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `beritas`
--

LOCK TABLES `beritas` WRITE;
/*!40000 ALTER TABLE `beritas` DISABLE KEYS */;
/*!40000 ALTER TABLE `beritas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('stba-pontianak-cache-078b8f7f7281e5b3820a2fe9d33870127bec4cfc','i:2;',1773189050),
('stba-pontianak-cache-078b8f7f7281e5b3820a2fe9d33870127bec4cfc:timer','i:1773189050;',1773189050),
('stba-pontianak-cache-active_marquee','s:65:\"PENGUMUMAN 📢📢: Pendaftaran PMB STBA Pontianak telah dibuka.\";',1779683831),
('stba-pontianak-cache-livewire-rate-limiter:442221d2f62dfc35304b9399be9ecd97fd1334e9','i:2;',1779158715),
('stba-pontianak-cache-livewire-rate-limiter:442221d2f62dfc35304b9399be9ecd97fd1334e9:timer','i:1779158715;',1779158715),
('stba-pontianak-cache-livewire-rate-limiter:47b6a3c29f417db1011c756eac6e6187689cfdca','i:1;',1774546223),
('stba-pontianak-cache-livewire-rate-limiter:47b6a3c29f417db1011c756eac6e6187689cfdca:timer','i:1774546223;',1774546223),
('stba-pontianak-cache-livewire-rate-limiter:7f497701a96be8c1ffac1c068599f6c7ef8a9093','i:1;',1773207289),
('stba-pontianak-cache-livewire-rate-limiter:7f497701a96be8c1ffac1c068599f6c7ef8a9093:timer','i:1773207289;',1773207289),
('stba-pontianak-cache-livewire-rate-limiter:a6a8cc398c9106623ac09c947605f544883ae29e','i:1;',1773210420),
('stba-pontianak-cache-livewire-rate-limiter:a6a8cc398c9106623ac09c947605f544883ae29e:timer','i:1773210420;',1773210420),
('stba-pontianak-cache-livewire-rate-limiter:baa788f5864d30c47b0fe691fff1f0255eebbcde','i:1;',1778677603),
('stba-pontianak-cache-livewire-rate-limiter:baa788f5864d30c47b0fe691fff1f0255eebbcde:timer','i:1778677603;',1778677603),
('stba-pontianak-cache-livewire-rate-limiter:bfc744c3cf3e5b63067e9d405ee56f219eb6024a','i:1;',1779679297),
('stba-pontianak-cache-livewire-rate-limiter:bfc744c3cf3e5b63067e9d405ee56f219eb6024a:timer','i:1779679297;',1779679297),
('stba-pontianak-cache-livewire-rate-limiter:c2ef0a170678e9064a0dc965616eb1fd10cc88a6','i:1;',1779678681),
('stba-pontianak-cache-livewire-rate-limiter:c2ef0a170678e9064a0dc965616eb1fd10cc88a6:timer','i:1779678681;',1779678681),
('stba-pontianak-cache-livewire-rate-limiter:d4b8fa2cb42c62cb64ad4ce869160d26d26481c5','i:1;',1773208786),
('stba-pontianak-cache-livewire-rate-limiter:d4b8fa2cb42c62cb64ad4ce869160d26d26481c5:timer','i:1773208786;',1773208786),
('stba-pontianak-cache-livewire-rate-limiter:ef157877124d9cd95fef6be0437545c136b6e320','i:1;',1775384183),
('stba-pontianak-cache-livewire-rate-limiter:ef157877124d9cd95fef6be0437545c136b6e320:timer','i:1775384183;',1775384183),
('stba-pontianak-cache-livewire-rate-limiter:f89c219bc457659bf00ac484ae5f7c1c44b0042e','i:2;',1779157164),
('stba-pontianak-cache-livewire-rate-limiter:f89c219bc457659bf00ac484ae5f7c1c44b0042e:timer','i:1779157164;',1779157164),
('stba-pontianak-cache-livewire-rate-limiter:f8cbe57ccc35ef452d2eaa5e89f348b137a6868e','i:1;',1773196810),
('stba-pontianak-cache-livewire-rate-limiter:f8cbe57ccc35ef452d2eaa5e89f348b137a6868e:timer','i:1773196810;',1773196810),
('stba-pontianak-cache-setting.FONNTE_API_TOKEN','N;',1779162391),
('stba-pontianak-cache-setting.RECAPTCHA_SECRET_KEY','s:40:\"6LcBpIMsAAAAAPZ5h1LCd379oijTM9E32RGS3F5y\";',1779681603),
('stba-pontianak-cache-setting.RECAPTCHA_SITE_KEY','s:40:\"6LcBpIMsAAAAAMmF-3Mj5TBjIcpcvYG_PDSP0VoH\";',1779679388),
('stba-pontianak-cache-spatie.permission.cache','a:3:{s:5:\"alias\";a:0:{}s:11:\"permissions\";a:0:{}s:5:\"roles\";a:0:{}}',1779765022);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokumens`
--

DROP TABLE IF EXISTS `dokumens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dokumens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumens`
--

LOCK TABLES `dokumens` WRITE;
/*!40000 ALTER TABLE `dokumens` DISABLE KEYS */;
/*!40000 ALTER TABLE `dokumens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `deskripsi_singkat` text DEFAULT NULL,
  `deskripsi` longtext DEFAULT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `lokasi` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `events_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES
(1,'default','{\"uuid\":\"df8d6c8b-cb51-47de-aee5-b483e61cd8dd\",\"displayName\":\"App\\\\Mail\\\\PmbSubmissionMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":17:{s:8:\\\"mailable\\\";O:26:\\\"App\\\\Mail\\\\PmbSubmissionMail\\\":3:{s:12:\\\"registration\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:23:\\\"App\\\\Models\\\\Registration\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:24:\\\"muhammadazkraa@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:3:\\\"job\\\";N;}\"},\"createdAt\":1773208638,\"delay\":null}',0,NULL,1773208638,1773208638),
(2,'default','{\"uuid\":\"be0d92c7-5cbb-4e3f-a717-f675ee5f2e1c\",\"displayName\":\"App\\\\Mail\\\\PmbSubmissionMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":17:{s:8:\\\"mailable\\\";O:26:\\\"App\\\\Mail\\\\PmbSubmissionMail\\\":3:{s:12:\\\"registration\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:23:\\\"App\\\\Models\\\\Registration\\\";s:2:\\\"id\\\";i:2;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:19:\\\"abduelfqh@gmail.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:3:\\\"job\\\";N;}\"},\"createdAt\":1775585522,\"delay\":null}',0,NULL,1775585522,1775585522),
(3,'default','{\"uuid\":\"b810ab2d-8bec-410a-8d68-ad42bc6e0cc2\",\"displayName\":\"App\\\\Mail\\\\PmbSubmissionMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":17:{s:8:\\\"mailable\\\";O:26:\\\"App\\\\Mail\\\\PmbSubmissionMail\\\":3:{s:12:\\\"registration\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:23:\\\"App\\\\Models\\\\Registration\\\";s:2:\\\"id\\\";i:3;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:22:\\\"info@kementerian.go.id\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:3:\\\"job\\\";N;}\"},\"createdAt\":1776266596,\"delay\":null}',0,NULL,1776266596,1776266596);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kontaks`
--

DROP TABLE IF EXISTS `kontaks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kontaks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `tugas` varchar(255) NOT NULL,
  `nomor_hp` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `hari_layanan` varchar(255) DEFAULT NULL,
  `jam_layanan` varchar(255) DEFAULT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'bi-person-lines-fill',
  `urutan` int(11) NOT NULL DEFAULT 0,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kontaks`
--

LOCK TABLES `kontaks` WRITE;
/*!40000 ALTER TABLE `kontaks` DISABLE KEYS */;
/*!40000 ALTER TABLE `kontaks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marquees`
--

DROP TABLE IF EXISTS `marquees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marquees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marquees`
--

LOCK TABLES `marquees` WRITE;
/*!40000 ALTER TABLE `marquees` DISABLE KEYS */;
INSERT INTO `marquees` VALUES
(3,'PENGUMUMAN 📢📢: Pendaftaran PMB STBA Pontianak telah dibuka.',1,'2026-03-10 14:18:49','2026-05-13 12:07:44');
/*!40000 ALTER TABLE `marquees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_01_05_124105_create_settings_table',1),
(5,'2026_01_05_134301_create_beritas_table',1),
(6,'2026_01_05_142303_create_agendas_table',1),
(7,'2026_01_11_063921_create_stafs_table',1),
(8,'2026_02_04_103314_create_events_table',1),
(9,'2026_02_05_115851_add_no_hp_to_users_table',1),
(10,'2026_02_07_161007_create_registrations_table',1),
(11,'2026_02_10_082521_add_role_to_users_table',1),
(12,'2026_02_10_084305_create_permission_tables',1),
(13,'2026_02_10_084334_remove_role_from_users_table',1),
(14,'2026_02_24_195534_add_status_to_registrations_table',1),
(15,'2026_02_24_200633_add_feedback_to_registrations_table',1),
(16,'2026_03_02_123528_create_dokumens_table',1),
(17,'2026_03_02_171853_create_kontaks_table',1),
(18,'2026_03_10_135336_create_marquees_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(2,'App\\Models\\User',2),
(2,'App\\Models\\User',3),
(2,'App\\Models\\User',4),
(4,'App\\Models\\User',1),
(5,'App\\Models\\User',5);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registrations`
--

DROP TABLE IF EXISTS `registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `nik` varchar(255) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `email` varchar(255) NOT NULL,
  `no_hp` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `program_studi` varchar(255) NOT NULL,
  `sistem_kuliah` varchar(255) NOT NULL,
  `sekolah_asal` varchar(255) NOT NULL,
  `jurusan_sekolah` varchar(255) DEFAULT NULL,
  `tahun_lulus` varchar(255) NOT NULL,
  `ijazah_path` varchar(255) DEFAULT NULL,
  `foto_path` varchar(255) DEFAULT NULL,
  `step` int(11) NOT NULL DEFAULT 1,
  `status` enum('pending','proses','selesai') NOT NULL DEFAULT 'pending',
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `registrations_user_id_foreign` (`user_id`),
  CONSTRAINT `registrations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrations`
--

LOCK TABLES `registrations` WRITE;
/*!40000 ALTER TABLE `registrations` DISABLE KEYS */;
INSERT INTO `registrations` VALUES
(2,11,'Abdul Faqih','6104070811070001','2007-11-08','L','abduelfqh@gmail.com','082195109235','Dusun Suka Ramai, RT.001/RW.001, Desa Sukaramai, Kecamatan Sungai Laur','S1 Sastra Inggris','Reguler (Pagi)','SMAS MA ARIF','Lainnya','2025','documents/ijazah/0pqy1fWKOTBxfgX5212776mkIg6Xq0EcvMtY2maW.jpg','documents/foto/xphsbLC77bRAEq0pRfn2ngZ5QWKrcaDYTlRS1jbT.jpg',3,'pending',NULL,'2026-04-07 16:31:09','2026-04-07 17:12:02'),
(3,12,'rizalmulyono','7371092003925432','2000-12-12','L','info@kementerian.go.id','08598563210','jl.setiabudi rt04/rw05','D3 Bahasa Inggris','Eksekutif (Malam)','dfgdfgdfgdfg','IPA','2020','documents/ijazah/TQyPGYmu032VWKH6QbmzGQuZ4JHKAmJs4VQXxfEC.jpg','documents/foto/eVWxK7emfCXaFGcy1PRFLOAqMXsSfs4SL5brbE3g.jpg',3,'pending',NULL,'2026-04-15 14:22:36','2026-04-15 14:23:16');
/*!40000 ALTER TABLE `registrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'admin','web','2026-03-08 00:14:52','2026-03-08 00:14:52'),
(2,'user','web','2026-03-08 00:14:52','2026-03-08 00:14:52'),
(3,'admin','admin','2026-03-08 00:14:52','2026-03-08 00:14:52'),
(4,'Super Admin','admin','2026-03-10 14:17:09','2026-03-10 14:17:09'),
(5,'Admin PMB','admin','2026-03-10 14:17:09','2026-03-10 14:17:09');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('07wLXFaU7vzzdFvUN3mQGR2IJRBqJYNx3adspCvo',NULL,'20.100.172.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoicms0VUdQWHlaOHZRUUl1T0dkcFdYQUYza1ZuUDZIbE5KY1JHbnhJTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9pbmRleC5waHAiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779673612),
('11IZot4VDZhrfGVtHCF7OaqdFIwdQ1FNyzP1i8gl',NULL,'47.128.124.129','Mozilla/5.0 (Linux; Android 5.0) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36 (compatible; Bytespider; spider-feedback@bytedance.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUnJmSFp4bTdkRFdDZUJJeU9pTzFYcWNiRGJDTGFEZzg4UWpxYmZrSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vd3d3LnN0YmFwb250aWFuYWsuYWMuaWQiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779678479),
('13qlVWdQtMJN3ZLcbhHSplxesXhounyDw6DYC2PZ',NULL,'43.218.233.154','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWHlqRzdZSlhaSzFzOFl6cXFpMDU3cDB2cmRSSUwzMXhDTVhpZHRjTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjE6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC8/cmVzdF9yb3V0ZT0lMkZ3cCUyRnYyJTJGdXNlcnMlMkYiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779679439),
('3lBzCXvUguaMVLUsEFrAljYAMXekxUitBzgQtm0q',NULL,'192.71.2.99','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoia3RPSzE5eDRkZXNCVWd5NVVNQkdOaTZsTE1CNVZ4OVVwZlI0Z2k3diI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9wcm9kaS9kMyI7czo1OiJyb3V0ZSI7czo4OiJwcm9kaS5kMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779678815),
('3ZdhcueXPkEfss3GAY3Y2xgmdYIDk2N88SuYDNzu',NULL,'192.71.126.207','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoialE3aXA2VGMzdXNacldHcmNMUlltY1hMQkpyYzRTeHFPRDBjRVE1ZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779678813),
('5NTpfZLE1seAuRzSPq5jMbFRWsslN9hFDNqNtJmI',NULL,'172.236.127.133','Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNnhpRndxVEd4NGp1dm1xWUQ1RWFmMGo4aG8ydkdwSk5rdXZlQUdYMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vNDMuMTMzLjE0Mi4yMzUiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779674176),
('74kL2xVjSbcC1unV22pt1uclD8YQ9MjCQdoMbieG',NULL,'172.213.208.33','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiajFlV0dZcXhPblZCWXFJdDdHVWFYTnh5bFk0WGN2bThWWktDYlBNdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vd3d3LnN0YmFwb250aWFuYWsuYWMuaWQvaW5kZXgucGhwIjtzOjU6InJvdXRlIjtzOjc6ImJlcmFuZGEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1779672960),
('7MoOht9ubWiNJv92SI3VzBdHUGl4g9BdGcMUubAi',NULL,'182.11.154.131','WhatsApp/2.23.20.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiY1pWQUdCVjJiNWt5aHdsTnUyNlN0b1k4NDJIY2tobDY2TmNIMmJkcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZG1pbi9sb2dpbiI7czo1OiJyb3V0ZSI7czoyNToiZmlsYW1lbnQuYWRtaW4uYXV0aC5sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779679401),
('7t24WA0cok16DhJVpMzdcFy7F7gm8clHycB6nqbK',NULL,'182.11.154.131','WhatsApp/2.23.20.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoieEx4a1hkZG1JNkdvY1ZKbjhCbWZVdWFSc0F1dThDUWJFZGRWRGNmRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZG1pbi9sb2dpbiI7czo1OiJyb3V0ZSI7czoyNToiZmlsYW1lbnQuYWRtaW4uYXV0aC5sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779679404),
('8bAkxuv8EZLD5yWxw1QCd9oaXWHsTTawqESs47af',NULL,'182.2.103.52','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSHRxWWdOMU5ZVjZxbzNucThsOWNGdkFKWkZjY1FsMXhxVGY1MTc1UiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9wcm9kaS9zMSI7czo1OiJyb3V0ZSI7czo4OiJwcm9kaS5zMSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779678818),
('a0eLVuq4v9myJnpPammotfTWNhwydXRH5vx4PJB6',NULL,'91.231.89.36','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVJIUGNXanRMV2l5aXRhVkk3ZDNTakRxeFZ3TTNIakdMVjE3S0V5ciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779680231),
('A7MGaiFZXpbN4yFhmvtU7K4dBpqvYl1iO701rxyU',NULL,'182.11.154.39','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoia0hzQm5xY0NZYk0zM1R0bHpROHYwczMwYkdoQ3lSbk83ZVRpajZINyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9rb250YWsiO3M6NToicm91dGUiO3M6Njoia29udGFrIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779676392),
('c4J8Nwr2L9Gx3Y1cS04gWQEnkJyxHX0XVPyYnBbk',NULL,'64.233.172.73','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibW1TMWFPM3pUT2gxSjdpSGhKVmRvYk85cU5LZXBZV2N2Q0JCdUoyQyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZ2VuZGEiO3M6NToicm91dGUiO3M6MTI6ImFnZW5kYS5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779680498),
('C5wyUj8HqJjQ8kCbUUwFqk60XkrZRVgCpfuT3oqv',NULL,'91.196.152.148','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN1l4dlNIcU1XRXB4MzI2S0d6UW53bDNSMmh5Y051aXJDZE5tdGhQcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779680374),
('CyBRldsFK6uiXLqNsuVbOPk6x2kluclPPuF0RoUz',NULL,'45.154.98.96','Mozlila/5.0 (Linux; Android 7.0; SM-G892A Bulid/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Moblie Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQzV3RkJpcnJHeEJuUlVmaUExa1puMlkyNXNiYmlVTVpwWDZxckNwMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779678559),
('eSKCPLwSIBHxHenM1TOAMWpeZx99mAD1PhDOMPhp',NULL,'64.233.172.73','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVnhSUFNVTlRjSWFtZVZncDNEdUVCS3hKeDdOejluTW1IQ0M5cEFndyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZ2VuZGEiO3M6NToicm91dGUiO3M6MTI6ImFnZW5kYS5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779680498),
('f057Qos8UkYmUCXMSDrgoVtxXimSNYwlHmmZc0RH',NULL,'38.43.64.53','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNVFRV2xBSDlUYTAzeVRmeUxDMW9pT2tSTG05VkVlaEhBTzhPZTJKdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9yZWdpc3RlciI7czo1OiJyb3V0ZSI7czo4OiJyZWdpc3RlciI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779680461),
('I2xtwy0nHYvJ4uZFHN4A224E78w7HwXBnWEReJA6',NULL,'182.11.154.131','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQnBYcEU1ZWphZXJTTk1jSW9yMVdIMG1jNk5BRXlkME5Rblk0dExtSSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZG1pbi9sb2dpbiI7czo1OiJyb3V0ZSI7czoyNToiZmlsYW1lbnQuYWRtaW4uYXV0aC5sb2dpbiI7fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6MzM6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZG1pbiI7fX0=',1779679365),
('I7Wwof3oEmUXHoWopOhUQWSU0j0JCrLVJajycLyS',NULL,'192.71.12.112','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN3ppNGFMM1lNVTc3R0hLUVE2MjNjUW91cG5tU1RGTmtNVlI1cFc1WSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779678812),
('iQtBwJmbCjUMMqLRR3fWyTolO4ns1HiWKNSY8Xdl',1,'182.11.154.39','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiZ21qR1VNY1VMQmUzWjlZektSMUFncFExVEZ6VmYyZFh3Q3NtUUhJNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZG1pbiI7czo1OiJyb3V0ZSI7czozMDoiZmlsYW1lbnQuYWRtaW4ucGFnZXMuZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MjoibG9naW5fYWRtaW5fNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTk6InBhc3N3b3JkX2hhc2hfYWRtaW4iO3M6NjQ6IjliYzdjZDNkZmIxOWMzMGM5YTZmNjM0ODJmNTcyMjRiNGFhMjZhNzA1NDdiYThmMmY1MmZlYmZmZmNlMDhjOTkiO3M6NjoidGFibGVzIjthOjM6e3M6NDA6ImU0MTZjOTkyZmRmNjViOTE5ZDVkMGI5NWZkMzZhYTM0X2NvbHVtbnMiO2E6NDp7aTowO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjEyOiJuYW1hX2xlbmdrYXAiO3M6NToibGFiZWwiO3M6NDoiTmFtYSI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjE7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTM6InByb2dyYW1fc3R1ZGkiO3M6NToibGFiZWwiO3M6NToiUHJvZGkiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aToyO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjY6InN0YXR1cyI7czo1OiJsYWJlbCI7czo2OiJTdGF0dXMiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aTozO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjEwOiJjcmVhdGVkX2F0IjtzOjU6ImxhYmVsIjtzOjE0OiJUYW5nZ2FsIERhZnRhciI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO319czo0MDoiZTE2ZTIxMTJiYWVhOWE0ZTJjNGMwZmQ5MWZiOTk2ZWZfY29sdW1ucyI7YTo0OntpOjA7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6NjoiZ2FtYmFyIjtzOjU6ImxhYmVsIjtzOjY6IkdhbWJhciI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjE7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6NToianVkdWwiO3M6NToibGFiZWwiO3M6NToiSnVkdWwiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aToyO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjc6InRhbmdnYWwiO3M6NToibGFiZWwiO3M6NzoiVGFuZ2dhbCI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjM7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTA6ImNyZWF0ZWRfYXQiO3M6NToibGFiZWwiO3M6NjoiRGlidWF0IjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MDtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MTtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO2I6MTt9fXM6NDA6IjJmNTM4MjE4ODI3MzJiY2EzYTcwNjM2ZjEwMGJhMzE3X2NvbHVtbnMiO2E6NDp7aTowO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjU6Imp1ZHVsIjtzOjU6ImxhYmVsIjtzOjU6Ikp1ZHVsIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6MTthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czoxMzoidGFuZ2dhbF9tdWxhaSI7czo1OiJsYWJlbCI7czo1OiJNdWxhaSI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjI7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTU6InRhbmdnYWxfc2VsZXNhaSI7czo1OiJsYWJlbCI7czo3OiJTZWxlc2FpIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6MzthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czoxMDoiY3JlYXRlZF9hdCI7czo1OiJsYWJlbCI7czo2OiJEaWJ1YXQiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjowO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjoxO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7YjoxO319fX0=',1779679439),
('iWO09f9i63t4NPkyhWYDXyxT9bb37RtLi5smAGtf',NULL,'31.169.53.71','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNkJyZE11R2dRRXRIRkR6eGtqQjdOQUU1Y0hkVTdEWGhrV3hqR1VNQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779678725),
('kSjvGTb3Kbxu2Nv5sT70RHCMybGpwsErbWO0FAdq',NULL,'36.106.166.54','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTERHaXp2ZGQ4MFdqQVIwSzhqNHNFT2hlV1pCYXNobVNrc0xicTdHaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vNDMuMTMzLjE0Mi4yMzUiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779673243),
('KXBwLfg755IJunPu9JmjHE390XbBJnlSS5gV71sD',NULL,'20.9.81.163','','YTozOntzOjY6Il90b2tlbiI7czo0MDoiR1pVdXFpaTB3eWd4MklESmk5NXJ3VGU3empLVmFCeFhqWmhrM2RnTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9pbmRleC5waHAiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779676736),
('mncPFEGRc5VFa3CTWbjAvxQV13fSWdImWzi0RF1C',NULL,'64.227.187.60','python-requests/2.33.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVI4bW13a05ma1VtNzBBRmRPbnAyNjRFUmZtQmZ0SGQyeG5NaHpMRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779672337),
('ngGkBO5nEPKaPrD5MxxHXxn25TUtFLUWls7xgRiO',NULL,'64.227.187.60','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHRJaHVTRVZuc2ZrZkQ1TkFucWJUYWxWRUtFRGFzdHY1SFhhVUFpbSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9pbmRleC5waHAiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779672386),
('nlg6G9hJAx7G0ifcnVq51nU7vzyn4PcYT7yqakY2',NULL,'182.11.129.154','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoibTBHN25DeHNIbXFZN3JQcUcySVBCV0JrekFlYnVmRGEyaE03RmVJSiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9wcm9kaS9kMyI7czo1OiJyb3V0ZSI7czo4OiJwcm9kaS5kMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779676551),
('NSvneCDb9RYMo6wH9z2HUcEBsF41MVwsX4j3aflu',NULL,'91.231.89.39','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZVJkVkZFSDcxNGdFVVIwWDBiNk5LUmFqVDd4YUZTb2pMNjBIelpVTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779680411),
('nTjYq8wSGpVHbo8BvYVIxfXwBlrBQn6uU2DsMOf9',NULL,'221.207.35.240','','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYk9EV294Y2h2U3pvbnR0elVYRG16QUJwczl6NVJjekF2TXd5clZkVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vNDMuMTMzLjE0Mi4yMzUiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779673193),
('OGqyfDLVbn6OJOUidA7ZwKGl7eEG5gbnY1dwVyaE',NULL,'192.71.126.53','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVWFVMEhuaTg2a2dTakl1dGdwN1lJWklBQnRHb2xaV2M0dE1sVDV2YSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDM6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9mb3Jnb3QtcGFzc3dvcmQiO3M6NToicm91dGUiO3M6MTY6InBhc3N3b3JkLnJlcXVlc3QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1779678814),
('OkWHk1Mp3hd3AH2fIpxTzushgna2vCpWLz8Qd8Ln',NULL,'182.11.154.131','WhatsApp/2.23.20.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSGdQeVlMU1kyeVVSYWpvMHFoSndQUXFxV2tNR2x4d3MzV3luSGw4QSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozMzoiaHR0cHM6Ly9zdGJhcG9udGlhbmFrLmFjLmlkL2FkbWluIjt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZG1pbiI7czo1OiJyb3V0ZSI7czozMDoiZmlsYW1lbnQuYWRtaW4ucGFnZXMuZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779679404),
('Oq0d2QtRs8pwIEZn7NF1BHzPltWCwWIhWXesK5Fo',NULL,'89.200.205.46','Mozilla/5.0 (compatible; OpenindexSpider; +https://www.openindex.io/saas/about-our-spider/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNFpCU1Q1b2ZqaFhxcXZGaENmYWRHNmhjY0VXdXRwRG50Rnk5T3EwaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779675289),
('plV1pWTaRfWNSPFqasCL6TPuDJn0cIQRbKhNSqmq',NULL,'192.71.2.119','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.1','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMUZadENEdTA1T2VQRVRhU1BmclpEWURjSXRsejVRWWR0YlJ6SXRCcCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozODoiaHR0cHM6Ly9zdGJhcG9udGlhbmFrLmFjLmlkL3BtYi9kYWZ0YXIiO31zOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozODoiaHR0cHM6Ly9zdGJhcG9udGlhbmFrLmFjLmlkL3BtYi9kYWZ0YXIiO3M6NToicm91dGUiO3M6MTA6InBtYi5kYWZ0YXIiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1779678813),
('Po092El70V0Lij7hJhmDxgDCVZ1LoCSTVFoywAp7',NULL,'43.157.149.188','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWWVEWHRZNk5NeFB1NEkxVGhSYzJ5RlZRSzlDbm5LSUs2aVl0amJJWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vd3d3LnN0YmFwb250aWFuYWsuYWMuaWQiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779682838),
('rBv75VcG8JZ4vKuxjAqW7LJxP34lEG6jcIez89YJ',NULL,'71.6.232.23','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSlVKYUUxUjE5Z0dSNzd0c0tUZmVxVnlsMG0xMGgzUE5RNGRuUkwyeiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vNDMuMTMzLjE0Mi4yMzUiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779681810),
('REvOW3dzrFjeFpKLNJEuM2gkG5Lc5vwSJRS5w0fV',NULL,'182.11.130.21','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiM0xhb3N5aTdOTFRGbUh1TEU3V1p6UHl6aHptTXd5WWZib3E5ZVc1SSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779677576),
('sJtKhJk1O3y0lUwwDhHEv8XFAwpZNijLNtjn2SFq',NULL,'72.14.201.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2FCYzE2NVdZUkJrZno0NXpFTzhjZU9Icml6cTFNVTNUUWJDVzk2NSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779676243),
('uoP91SjASNJ0ONA28QL9pFwDq5YCsf0AqHgLXm1p',NULL,'8.219.68.3','curl/7.74.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN04ycm5ZeXdHS1Bvakp5TG4wNWJwSjBmdjd4ZzdENFRFRDNqWTBHdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vNDMuMTMzLjE0Mi4yMzUiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779681743),
('UwaoBAm9qFnBi9koUfgtacnbQHStu3lG7VAQ0WhB',1,'182.11.154.39','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo3OntzOjY6Il90b2tlbiI7czo0MDoiaUVLb01tc0JScUZUQjRGSDZPVXhpbU5tMEZwVDhlS25hdDN4aFZPWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZG1pbi9rb250YWtzIjtzOjU6InJvdXRlIjtzOjM4OiJmaWxhbWVudC5hZG1pbi5yZXNvdXJjZXMua29udGFrcy5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6Mzg6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9wbWIvZGFmdGFyIjt9czo1MjoibG9naW5fYWRtaW5fNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTk6InBhc3N3b3JkX2hhc2hfYWRtaW4iO3M6NjQ6IjliYzdjZDNkZmIxOWMzMGM5YTZmNjM0ODJmNTcyMjRiNGFhMjZhNzA1NDdiYThmMmY1MmZlYmZmZmNlMDhjOTkiO3M6NjoidGFibGVzIjthOjM6e3M6NDA6ImU0MTZjOTkyZmRmNjViOTE5ZDVkMGI5NWZkMzZhYTM0X2NvbHVtbnMiO2E6NDp7aTowO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjEyOiJuYW1hX2xlbmdrYXAiO3M6NToibGFiZWwiO3M6NDoiTmFtYSI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjE7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTM6InByb2dyYW1fc3R1ZGkiO3M6NToibGFiZWwiO3M6NToiUHJvZGkiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aToyO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjY6InN0YXR1cyI7czo1OiJsYWJlbCI7czo2OiJTdGF0dXMiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aTozO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjEwOiJjcmVhdGVkX2F0IjtzOjU6ImxhYmVsIjtzOjE0OiJUYW5nZ2FsIERhZnRhciI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO319czo0MDoiNTIzNzUzYjc3NjBlMjM5NzZhMmY5YTE2ZTg1NTQ2NTJfY29sdW1ucyI7YTo0OntpOjA7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6NToianVkdWwiO3M6NToibGFiZWwiO3M6NToiSnVkdWwiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aToxO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjQ6ImZpbGUiO3M6NToibGFiZWwiO3M6NzoiRG9rdW1lbiI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjI7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTA6ImNyZWF0ZWRfYXQiO3M6NToibGFiZWwiO3M6MTA6IkNyZWF0ZWQgYXQiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjowO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjoxO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7YjoxO31pOjM7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTA6InVwZGF0ZWRfYXQiO3M6NToibGFiZWwiO3M6MTA6IlVwZGF0ZWQgYXQiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjowO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjoxO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7YjoxO319czo0MDoiNzRkZmIyMmI5ODhjNmI5MGNiZTBjMWE2YWIyYTExMDZfY29sdW1ucyI7YTo3OntpOjA7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6NDoibmFtYSI7czo1OiJsYWJlbCI7czo0OiJOYW1hIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6MTthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czo1OiJ0dWdhcyI7czo1OiJsYWJlbCI7czo1OiJUdWdhcyI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjI7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6ODoibm9tb3JfaHAiO3M6NToibGFiZWwiO3M6NjoiTm8uIEhQIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6MzthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czo1OiJlbWFpbCI7czo1OiJsYWJlbCI7czo1OiJFbWFpbCI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjQ7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTI6ImhhcmlfbGF5YW5hbiI7czo1OiJsYWJlbCI7czoxMjoiSGFyaSBMYXlhbmFuIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6NTthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czoxMToiamFtX2xheWFuYW4iO3M6NToibGFiZWwiO3M6MTE6IkphbSBMYXlhbmFuIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6NjthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czo1OiJha3RpZiI7czo1OiJsYWJlbCI7czo1OiJBa3RpZiI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO319fX0=',1779679499),
('V0eJgVz26PQSACeLN4qrzN3Lmd9sDJye7z5xSYXa',NULL,'193.176.29.6','Mozilla/5.0 (compatible; Infrawatch/1.0; +https://infrawat.ch/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSzZxSlN2VW81OHRBaWtKNENGVkNpMWRyS2d0M09JRGxMS1V5WmU1NCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vNDMuMTMzLjE0Mi4yMzUiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779678733),
('vQGs5yfnFxxl6Q2wHkJl4dnWiZMjOsQXI9a3JRw1',NULL,'85.211.241.140','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNmhhR1kwc0lFTWhxU05QVDB1NWg4V0RhR1hvUjFhMDZzd290NE8zdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779680403),
('w9LIQ1dFU4cszVRIHyNyxzYIevNdf8jl5SJZD2F6',NULL,'4.225.163.177','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWmZiR3dKQ1dsSmZjZ0pRaUY4VFpxTWFTVUgwNEdBcjROMDJOWFk3aSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9pbmRleC5waHAiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779675503),
('WBZUe36XffK5BHEnBwhaCVIYFm7ywXs0R52sTmvl',NULL,'8.219.68.3','curl/7.64.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoieGhWb2ZTWXFVa0RPS0EyQ1AxZXdreFFKdFRyQ3BQcE9sNTlSOGZkMSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vNDMuMTMzLjE0Mi4yMzUiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779681743),
('y0pzGNTQaWkmcCsqPRrU3xtHo6OJt0Jr1uRrYAx9',NULL,'91.196.152.45','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaTlCRDRGWWRoakxDT2dvUml1UjdKZ2QzU05LMlhNYkdGMEtFdDNuRCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779680686),
('ywHfvTpkCDaaMtDS5iBnFL8ruvfMDEzaM4cZ0Rum',NULL,'45.148.10.67','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN3hEdm92cU5Va0w3ekM5QW5Xdjl6cmxKNnJ3TDFXWjdUdWNNemRSWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vNDMuMTMzLjE0Mi4yMzUiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779674200),
('z5mgXrIxtPLWGYMwZs6lc9qFZXJeP7gk0glBtA1f',NULL,'45.148.10.67','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSDFvZ0NWUlNwMHhWZUVMU2pWWjQ2RjA0TmFFMXB3dDdhekZyYnRpcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vNDMuMTMzLjE0Mi4yMzUiO3M6NToicm91dGUiO3M6NzoiYmVyYW5kYSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1779682554),
('zds2uNKPEm1YItse42nJePo3Wh24rN9xdlcFIEx3',NULL,'182.11.154.107','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiWHBGbG1yakhEejNUaFRsVGZ1NktzQm52eGlqWXFscGp2blhVWWpvTSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZ2VuZGEiO3M6NToicm91dGUiO3M6MTI6ImFnZW5kYS5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6MzM6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZC9hZG1pbiI7fX0=',1779680493),
('zz4r1f6XV7zgJ6xVJf5T7WLhVW2NneWoswH7NFxD',NULL,'162.120.184.53','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOTlGS1pwdFVsd0JvUUhxQjh5MkVTbXBZVHlMaVhIRHhoeVZlbWlCVyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vc3RiYXBvbnRpYW5hay5hYy5pZCI7czo1OiJyb3V0ZSI7czo3OiJiZXJhbmRhIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779676244);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(3,'marquee_text','test1','2026-03-10 01:25:44','2026-03-10 01:25:44'),
(7,'FONNTE_API_TOKEN',NULL,'2026-03-11 04:51:50','2026-03-11 04:51:50'),
(8,'RECAPTCHA_SITE_KEY','6LcBpIMsAAAAAMmF-3Mj5TBjIcpcvYG_PDSP0VoH','2026-03-11 04:51:50','2026-03-11 04:51:50'),
(9,'RECAPTCHA_SECRET_KEY','6LcBpIMsAAAAAPZ5h1LCd379oijTM9E32RGS3F5y','2026-03-11 04:51:50','2026-03-11 04:51:50');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stafs`
--

DROP TABLE IF EXISTS `stafs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stafs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `posisi` varchar(255) DEFAULT NULL,
  `display_order` int(10) unsigned NOT NULL DEFAULT 1,
  `status_aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stafs`
--

LOCK TABLES `stafs` WRITE;
/*!40000 ALTER TABLE `stafs` DISABLE KEYS */;
/*!40000 ALTER TABLE `stafs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `no_hp` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Super Admin','admin@stbapontianak.ac.id','080000000000',NULL,'$2y$12$u0HMGdaGA50BK9NJSgIKweQKt/2NVSAcyfk7r6QggsmPWt85ulLFy','j6MColfRTbiHY4yIDvqIUJahXrricZcWGEvsAPKJkugZRb2hnE5aSZcu7u17','2026-03-08 00:14:52','2026-05-19 01:18:20'),
(3,'lFiOsQCnvjzpRkMMqnZcb','gu.saz.ih180@gmail.com',NULL,NULL,'$2y$12$m6TTv61FWqoHMsbT5gTWk.r9UdaLNk1U0K6DIJtvJWJ1dr5u9RFNm',NULL,'2026-03-08 17:45:31','2026-03-08 17:45:31'),
(4,'ojIYbuvgXmMNsDWXKhfff','te.d.a.w.e.t.e.2.77@gmail.com',NULL,NULL,'$2y$12$hPwK4ubj4kvXjAevWT0TDuhkuEjmzecdQsku51d7g3mF.Ct/v1ABW',NULL,'2026-03-09 02:48:33','2026-03-09 02:48:33'),
(5,'pmb','adminpmb@stbapontianak.ac.id','080000000000',NULL,'$2y$12$WFm5AdcX.hat7u/a2sP4ReFIPWr8PTyySzw4J4dXa0hY9Nn23UAC2',NULL,'2026-03-10 14:18:04','2026-05-19 01:06:43'),
(7,'Muhammad Azzikra Syani','muhammadazkraa@gmail.com',NULL,NULL,'$2y$12$7wFBQ8J0cOtXuiXgRwZzS.qXP2GJSXzf3RaI2/n6zYTR1lSumUuvO',NULL,'2026-03-11 04:54:31','2026-03-11 04:54:31'),
(8,'KlSNRhCBbnkwIcNqHZLNuR','q.e.s.on.o.neciz.04@gmail.com',NULL,NULL,'$2y$12$720xeJYOrKVagTYVV4EdFecPAmwyVOUY4a4EM5FnpacB/6ZSTzSFO',NULL,'2026-03-25 15:45:51','2026-03-25 15:45:51'),
(9,'KarinaNus','likers@muzgruz.site',NULL,NULL,'$2y$12$uZxZy4c0ia3QJYz3J/y7JewHqKJJVNZ/IzqX8E7ucSkKvorLJgPGG',NULL,'2026-03-29 11:15:12','2026-03-29 11:15:12'),
(10,'Fernando','kuyungteng39@gmail.com',NULL,NULL,'$2y$12$xv6i02M6SedeVvrFZUqdied0JojmjK4Ch8iqqqjcKp7W641/KpSva','CGo7pmkauIzjItaR6miltgcXHzwZdQxnJBHUozEoiZvcAC0bnysgW08WVImm','2026-04-06 01:20:38','2026-04-06 01:20:38'),
(11,'Abdul Faqih','abduelfqh@gmail.com',NULL,NULL,'$2y$12$VOzaXoJT6cjtTmUJ2HQgYOvePoUPRpI0QevJtmvOvbMxQZ30lJEw.','Y5E2esyKYhYcUnYuN9nG2s65KvpFINXcbY1ax2XbwxeqVmFnrJ0mvxjvA3Hs','2026-04-07 16:09:09','2026-04-07 16:09:09'),
(12,'rizalmulyono','suspicious.caribou.mipf@hidingmail.com',NULL,NULL,'$2y$12$AZUYYZQW4Oier7JGxhium.k09ShLdB1yP29F.5WXAr3lT68lGN1v6','XrsCNEGYjRPLNG5JQ3T4TSwvvcjoMBcAVXknFgfhSaHqBh5GGyQKEyKnHnwh','2026-04-15 14:20:41','2026-04-15 14:20:41'),
(13,'ZVXBetpXxbOqMubm','piv.u.gaxoso.9.0@gmail.com',NULL,NULL,'$2y$12$pKmTG.x5MQrlQhijmymCN.CEamrklT3rqpHyV9tn4cYllRJL08J6.',NULL,'2026-04-19 04:24:34','2026-04-19 04:24:34'),
(14,'GGXRQGyVlwxqFMrSKkfUIeU','i.yu.fuxi.t.o.to971@gmail.com',NULL,NULL,'$2y$12$F8EInaxNjcNtJm2L6dmVQ.5Bsp4SpHPs9iVu5vcmi3Pqv8SE/HLrm',NULL,'2026-04-28 18:07:01','2026-04-28 18:07:01'),
(15,'ggLXcKbiATQIMekN','i.yuk.apum.41@gmail.com',NULL,NULL,'$2y$12$.V0PrHli.eFRWCvnutWk8ew8SizijW6U8s0Hd406KCIEWQxqyWv/C',NULL,'2026-05-03 08:32:58','2026-05-03 08:32:58'),
(16,'mRXrlhFYKezwoETJeQruqUv','q.i.n.eno.z.ej.9.42@gmail.com',NULL,NULL,'$2y$12$EA.DWzFMOo4ZG/8D5P.a6O7/cMAaQSk6pIwaLSbOqK6vNEfXxvmPu',NULL,'2026-05-06 01:24:26','2026-05-06 01:24:26'),
(17,'nnHNSGWIEHbKSwkuAbesyO','jole.h.a.jot.ur329@gmail.com',NULL,NULL,'$2y$12$f8KS1.PkIDCo9pY7guqYKentXdiWxyJ/VRynXN6tAXbtyCcMZ9Dpq',NULL,'2026-05-08 01:45:22','2026-05-08 01:45:22'),
(18,'gWheylscuBeYzFVPkf','i.f.i.satex.4.7.6@gmail.com',NULL,NULL,'$2y$12$THW8mWccL91jUSzAkWMI4O7dSdftc6xXCX50CwGZaJNDOD9mLfIpK',NULL,'2026-05-08 08:22:19','2026-05-08 08:22:19'),
(19,'Velisia Chrisveritas','velisiachtisveritas@gmail.com',NULL,NULL,'$2y$12$yKMIEKIbhnlqxJqsNnTniebjiyWFipzvryVqhkz4SMYOtCEwZkWV6',NULL,'2026-05-09 20:01:32','2026-05-09 20:01:32'),
(20,'RgQjfiGiyjtdxysibrqcP','fa.k.ix.adi28@gmail.com',NULL,NULL,'$2y$12$AA8fI.AoXvgJioDSsw8sOuInd6FCWPva9bGQlL6LnQPHmE6djVTQK',NULL,'2026-05-14 10:16:32','2026-05-14 10:16:32'),
(21,'oeEIylxIFJMjIZLZNON','efeb.ow.i.he.h8.8@gmail.com',NULL,NULL,'$2y$12$yVL2YAROWgwB0GcEEgVO3.5y6OUe8XlD1d1p5d/pWHl7e2qTD8fqS',NULL,'2026-05-18 03:06:52','2026-05-18 03:06:52'),
(22,'sukardi','vincentlayarda8@gmail.com',NULL,NULL,'$2y$12$E7mrvcTlkU1qvGsUy54qkeCQCDJdwFGSAH1DNK7afjJt9zYdPNY2e',NULL,'2026-05-19 01:10:05','2026-05-19 01:10:05'),
(23,'PsoByfJZirxUOnCUFlrkW','b.opubud.owu.49@gmail.com',NULL,NULL,'$2y$12$zqAjpYA0mhyaN0RHzqD6LuyphPqdgF8C8byA09kAoZMfHgk0Ux3jq',NULL,'2026-05-21 22:25:06','2026-05-21 22:25:06'),
(24,'ZRgSEelDkuBTvKCWEJPa','eniv.iq.an.e.j.86@gmail.com',NULL,NULL,'$2y$12$4.nprUrw.QnNonuQtDghA.Tmkq3B6ryOurJzguCUM9ZuUifISdU9a',NULL,'2026-05-23 00:31:46','2026-05-23 00:31:46');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sql_stbapontianak_ac_id'
--

--
-- Dumping routines for database 'sql_stbapontianak_ac_id'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-25 12:22:20
